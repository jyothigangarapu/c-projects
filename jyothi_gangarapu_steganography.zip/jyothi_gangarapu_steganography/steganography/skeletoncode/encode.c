/*Name : Johnsy
  Date : 22/11/2024
  Project Name : stegnography */
#include <stdio.h>
#include <string.h>
#include "encode.h"
#include "types.h"
#include "common.h"

/* Function Definitions */

/* Get image size
 * Input: Image file ptr
 * Output: width * height * bytes per pixel (3 in our case)
 * Description: In BMP Image, width is stored in offset 18,
 * and height after that. size is 4 bytes
 */

/* Check operation type */
OperationType check_operation_type(char *argv[])
{
	//Checking encode
	if (strcmp("-e", argv[1]) == 0)
	{
		return e_encode;
	}
	//Checking decode
	if (strcmp("-d", argv[1]) == 0)
	{
		return e_decode;
	}
	if (strcmp(" ", argv[1]) == 0)
	{
		return e_unsupported;
	}

}

/*check read and validation function
check arguments required files passed  or not*/
Status read_and_validate_encode_args(char *argv[], EncodeInfo *encInfo)
{
       int len=strlen(argv[2]);// check argv[2] is .bmp or not if false return e_failure.
         if(!(strcmp(&argv[2][len-4],".bmp")))
         {
            encInfo->src_image_fname=argv[2];// store argv[2] into the structure member.
         }
         else{
              printf("The file does not contain .bmp extension\n");
              return e_failure;
         }
         len=strlen(argv[3]); // check argv[2] is txt , .sh or .c or not if false return e_failure.
         if((!(strcmp(&argv[3][len-4],".txt"))||(!strcmp(&argv[3][len-2],".c"))||(!strcmp(&argv[3][len-3],".sh"))))//check argv[3] is .txt or not 
         {
            encInfo->secret_fname=argv[3];// store argv[3] into the structure member.
           
         }
         else{
            printf("The file does not contain .txt , .sh or .c extension\n");
            return e_failure;
         }
         if(argv[4]==NULL)// checking argv[4] is NULL or not if it is null store default.bmp into the structure member
            encInfo->stego_image_fname="jyothi.bmp";// store into the stego
         else
         {
            len=strlen(argv[4]);
            if(!(strcmp(&argv[4][len-4],".bmp")))// checking whether argv[4] is having .bmp or not ,if false return e_failure.
            {
               encInfo->stego_image_fname=argv[4];// store into the structure member //
            }
            else
                 return e_failure;
        }
        return e_success;// all are valid agrument than return the e_success
}
/*
 * Get File pointers for i/p and o/p files
 * Inputs: Src Image file, Secret file and
 * Stego Image file
 * Output: FILE pointer for above files
 * Return Value: e_success or e_failure, on file errors
 */
Status open_files(EncodeInfo *encInfo)
{
    // opening Src Image file
    encInfo->fptr_src_image = fopen(encInfo->src_image_fname, "r");
    // Do Error handling
    if (encInfo->fptr_src_image == NULL)
    {
        perror("fopen");
        fprintf(stderr, "ERROR: Unable to open file %s\n", encInfo->src_image_fname);
	//If it is null returns e_failure
        return e_failure;
    }

    // Secret file
    encInfo->fptr_secret = fopen(encInfo->secret_fname, "r");
    // Do Error handling
    if (encInfo->fptr_secret == NULL)
    {
        perror("fopen");
        fprintf(stderr, "ERROR: Unable to open file %s\n", encInfo->secret_fname);

        return e_failure;
    }

    // Stego Image file
    encInfo->fptr_stego_image = fopen(encInfo->stego_image_fname, "w");
    // Do Error handling
    if (encInfo->fptr_stego_image == NULL)
    {
        perror("fopen");
        fprintf(stderr, "ERROR: Unable to open file %s\n", encInfo->stego_image_fname);
	
        return e_failure;
    }

    // No failure return e_success
    return e_success;

}
// Checks if the BMP image has enough capacity to encode the secret file data
Status check_capacity(EncodeInfo *encInfo)
{
        encInfo -> image_capacity = get_image_size_for_bmp(encInfo -> fptr_src_image); // Get image capacity
        //printf("Image capacity : %u bytes\n", encInfo -> image_capacity);


        encInfo -> size_secret_file = get_file_size(encInfo -> fptr_secret); // Get size of secret file
	printf("Checking capacity to encode message\n");
        int size = 54 + ((2 + 4 + 4 + 4 + encInfo -> size_secret_file)) * 8; // Calculate required size
        //printf("size is : %d bytes\n", size);
	
	// Check if image capacity is sufficient for the data to be encoded
        if (encInfo -> image_capacity > 54 + ((2 + 4 + 4 + 4 + encInfo -> size_secret_file)) * 8)
        {
		printf("Capacity of source file is more than the secret file.\n");
                return e_success;   
        }
        else
        {
		printf("Capacity of source file is more than the secret file.\n");
                return e_failure;   
        }

}
uint get_image_size_for_bmp(FILE *fptr_image)
{
    uint width, height;
    // Seek to 18th byte
    fseek(fptr_image, 18, SEEK_SET);

    // Read the width (an int)
    fread(&width, sizeof(int), 1, fptr_image);
    printf("width = %u\n", width);

    // Read the height (an int)
    fread(&height, sizeof(int), 1, fptr_image);
    printf("height = %u\n", height);

    // Return image capacity
    return width * height * 3;
}
// Function to get the file size
uint get_file_size(FILE *fptr_secret)
{
	fseek(fptr_secret, 0, SEEK_END); // Move file pointer to end
	return ftell(fptr_secret); // Return current position as file size
}
// Copies the BMP header from the source image file to the destination image file
Status copy_bmp_header(FILE *fptr_src_image, FILE *fptr_dest_image)
{
	char buffer[54];  // Buffer for header
	rewind(fptr_src_image);

	fread(buffer, 54, 1, fptr_src_image); // Read header
	fwrite(buffer, 54, 1, fptr_dest_image); // Write header to stego file
	printf("Header is copying\n");
	return e_success;
}
// Encodes the magic string (a signature) into the BMP image file
Status encode_magic_string(const char *magic_string, EncodeInfo *encInfo)
{

	// calling encode_data_to_image and Encode magic string
        encode_data_to_image(magic_string, strlen(magic_string), encInfo -> fptr_src_image, encInfo -> fptr_stego_image);
	return e_success;
}
// Function to encode the size of the secret file's extension
Status encode_secret_file_extn_size(long extn_size, EncodeInfo *encInfo)
{
        char buffer[32]; // Buffer for reading image data
	// Read data from source
        fread(buffer, 32, 1, encInfo -> fptr_src_image);
	// calling int_to_lsb function
        encode_int_to_lsb(extn_size, buffer);
	// Write to stego file
        fwrite(buffer, 32, 1, encInfo -> fptr_stego_image);
        return e_success;
}
// Function to encode the secret file's extension into the stego image
Status encode_secret_file_extn(const char * file_extn, EncodeInfo * encInfo)
{
	//calling data_to_image function
        encode_data_to_image(file_extn, strlen(file_extn), encInfo -> fptr_src_image, encInfo -> fptr_stego_image);
        return e_success;
}
// Function to encode the size of the secret file into the stego image
Status encode_secret_file_size(long file_size, EncodeInfo *encInfo)
{
	// Buffer for reading image data
        char buffer[32];
	// Read data from source
        fread(buffer, 32, 1, encInfo -> fptr_src_image);
	// Calling int_to_lsb function
        encode_int_to_lsb(file_size, buffer) ;
	// Write to stego file
        fwrite(buffer, 32, 1, encInfo -> fptr_stego_image);
        return e_success;
}
// Encodes the data from the secret file into the BMP image file
Status encode_secret_file_data(EncodeInfo *encInfo)
{
	rewind(encInfo -> fptr_secret);
        char secret_data[encInfo -> size_secret_file];
	//Reading size bytes of secret file
	fread(secret_data, encInfo -> size_secret_file, 1, encInfo -> fptr_secret);
	//Function call
	encode_data_to_image(secret_data, encInfo -> size_secret_file, encInfo -> fptr_src_image, encInfo -> fptr_stego_image);
	//Storing size bytes of secret file 
	fwrite(secret_data, encInfo -> size_secret_file, 1, encInfo -> fptr_secret);

        return e_success;
}
// Function to encode data into the stego image
Status encode_data_to_image(const char *data, int size, FILE *fptr_src_image, FILE *fptr_stego_image)
{
        char buffer[8]; // Buffer for reading image data
        for (int i = 0; i < size; i++)
        {
		// Read 8 bytes from the original file
                fread(buffer, 8, 1, fptr_src_image);
		// Function call to encode byte
                encode_byte_to_lsb(data[i], buffer);
		// Write the encoded data to the stego file
                fwrite(buffer, 8, 1, fptr_stego_image);
        }
	return e_success;
}
// Encodes a byte into the least significant bits of an image buffer
Status encode_byte_to_lsb(char data, char * buffer)
{
	int i, get;
	// Encode each bit
	for(i = 7; i >= 0; i--)
	{
		//get bit from msb
		get = (data & (1 << i)) >> i;
		//clear the bit in lsb
		buffer[7 - i] = buffer[7 - i] & (~1);
		//set bit on lsb
		buffer[7 - i] = buffer[7 - i] | get;
	}
}
// Encodes an integer into the least significant bits of an image buffer
Status encode_int_to_lsb(int data, char *buffer)
{
        int i, get;

        for (i = 31; i >= 0; i--)
        {
		//get bit from msb
                get = ((data & 1 << i) >> i);
		//clear the bit in lsb
                buffer[31 - i] = buffer[31 - i] & (~1);
		//set bit on lsb
                buffer[31 - i] = buffer[31 - i] | get;
        }
        return e_success;
}
// Copies the remaining image data from the source file to the destination file
Status copy_remaining_img_data(FILE *fptr_src, FILE *fptr_dest)
{
	//Copy remaining data to output file upto end of file
	//return e_success
        char buffer;
        while ( fread(&buffer, 1, 1, fptr_src) != 0)
        {
                fwrite(&buffer, 1, 1, fptr_dest);
        }
        return e_success;
}
// Function to perform the encoding process
Status do_encoding(EncodeInfo *encInfo)
{
	printf("Open files proccess started\n");
	printf("Encoding file :%s\n", encInfo -> stego_image_fname);
	// open files
	if (open_files(encInfo) == e_success)
	{
		printf("Files opened successfully\n");
		// Check Capacity
		if (check_capacity(encInfo) == e_success)
		{
			// copy bmp header 
			if (copy_bmp_header(encInfo -> fptr_src_image, encInfo -> fptr_stego_image) == e_success)
			{
				printf("Successfully header is copied\n");
				printf("Encoding the magic string\n");
				// magic string 
				if (encode_magic_string(MAGIC_STRING, encInfo) == e_success)
				{
					printf("Magic string Encoding successfully\n");
					printf("Encoding the file Extension size\n");
					// secret file extenstion size
					if (encode_secret_file_extn_size(strlen(encInfo -> extn_secret_file), encInfo) == e_success)
					{
						printf("File Extension size encoded successfully\n");
						printf("Encoding the file Extension Size\n");
						// secret file extenstion
						if (encode_secret_file_extn(encInfo -> extn_secret_file, encInfo) == e_success)
						{
							printf("File Extension Encoded Successfully\n");
							printf("Encoding secret file size(data size)\n");
							// secret file size
							if (encode_secret_file_size(encInfo -> size_secret_file, encInfo) == e_success)
							{
								printf("File size is encoded successfully\n");
								printf("Encoding the secret data\n");
								// secret file data
								if (encode_secret_file_data(encInfo) == e_success)
								{
									printf("Secret Data Encoded successfully\n");
									// copy remaining image data
									if (copy_remaining_img_data(encInfo -> fptr_src_image, encInfo -> fptr_stego_image) == e_success)
									{
										printf("Encoded the Remaining Data\n");
										printf("INFO:Done\n");
									// Close files
       								fclose(encInfo->fptr_src_image);
        							fclose(encInfo->fptr_secret);
        							fclose(encInfo->fptr_stego_image);
									FILE *fptr_output = fopen(encInfo->stego_image_fname, "r");
        
        							if (fptr_output != NULL) 
									{
           							// Print size of output file
            						uint output_size = get_file_size(fptr_output);
            						printf("OUTPUT FILE SIZE: %u bytes\n", output_size);
            
            						// Close fptr_output
            						fclose(fptr_output);
									  printf("all files closed successfully\n");
									  return e_success;
									}

									}
									else
									{
										printf("Encoded unsuccessfully.\n");
										return e_failure;
									}

								}
								else
								{
									printf("Encoded unsuccessfully.\n");
                                                                        return e_failure;
								}

							}
							else
                                             		{
								printf("Encoded unsuccessfully.\n");
								return e_failure;
							}

						}
						else
						{
							printf("Encode unsuccessfully.\n");
							return e_failure;
						}

					}
					else
					{
						printf("Encoded unccessfully\n");
						return e_failure;
					}


				}
				else
				{
					printf("Encoded unccessfully\n");
					return e_failure;
				}
			        

			}
			else
			{
				printf("Encoded unccessfully\n");
				return e_failure;
			}

		}
		else
		{
			printf("Encoded unccessfully\n");
			return e_failure;
		}
	}
	else
	{
		printf("Encoded unccessfully\n");
		return e_failure;
	}
}













