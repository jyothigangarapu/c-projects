#include<stdio.h>
int x=5;