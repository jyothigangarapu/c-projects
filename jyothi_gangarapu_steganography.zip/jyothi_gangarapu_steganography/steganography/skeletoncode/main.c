/* Documentation
   Name: Gangarapu Jyothi
   Date: 12/04/2025
   Project: Lsb image steganography
   Batch id:24038_039
  */
#include <stdio.h>
#include "encode.h"
#include "types.h"
#include "decode.h"

int main(int argc, char *argv[])
{
	//Checking if command line arguments are greater than 1 or not
	if (argc >=4 )
	{
		//Calling check_operation function
		//If it is true encoding will start
		if (check_operation_type(argv) == e_encode)
		{
			//Declaring structure variable
			EncodeInfo encInfo;
			//Function call
			
			
				printf("Encoding started.\n");
				printf("Arguments verified successfully\n");	
				if (read_and_validate_encode_args(argv, &encInfo) == e_success)
				{
					printf("read and validation done successfully\n");
					do_encoding(&encInfo);
					printf("Encoding is completed\n");
					return 0;
				}
			
			
		}

		//Calling check_operation function
		//If it is true decoding will start
		else if (check_operation_type(argv) == e_decode)
		{
			//Declaring structure variable
			DecodeInfo  decInfo;
			if (argc >= 2)
			{
				printf("Decoding started.\n");
				if (read_and_validate_decode_args(argv, &decInfo) == e_success)
				{
					//Function call
					printf("Arguments verified successfully\n");
					do_decoding(&decInfo);
					printf("Decoding is Completed.\n");
					return 0;
				}
			}
		}	
		else
		{
			printf("Error: unable to proceed operation provide valid type(-e or -d)\n");
				printf("For encoding arguments should be : \n");
				printf("./a.out -e <sourcefile.bmp> <secretfile.txt> <outputfile.bmp> (outputfile is optional)\n");
				printf("For encoding arguments should be : \n");
				printf("./a.out -d <sourcefile.bmp> <outputfile.bmp>\n");

			
		}



	}
	else{
		printf("user passed insufficient arguments\n");
		printf("ERROR : unable to perform operation. Arguments should be > 4\n");
		return e_failure;
	}

    
}
