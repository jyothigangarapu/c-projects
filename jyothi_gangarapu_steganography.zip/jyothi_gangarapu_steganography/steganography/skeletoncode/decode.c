/*Name : Johnsy
  Date : 22/11/2024
  Project Name : stegnography*/
#include <stdio.h>
#include "types.h"
#include "common.h"
#include "decode.h"
#include <string.h>
#include "encode.h"

Status read_and_validate_decode_args(char *argv[], DecodeInfo *decInfo)
{
	//check the soure file is .bmp or not
	printf("Checking arguments is started\n");
	if (strstr(argv[2], ".bmp") != NULL)
	{
		//storing input file name to char pointer
		decInfo -> encoded_image_fname = argv[2];
		//Checking cml if the user is given output file name or not
		if (argv[3] != NULL)
		{
			char str[100];
			strcpy(str,argv[3]);
		        char *token=strtok(str,".");
			//Storing if name is given in cml
                        strcpy(decInfo->output_fname, token);
		}
		else
		{
			//If uesr is not given output file name storing default name
			strcpy(decInfo -> output_fname , "output_secret");
		}
		return e_success;
	}
	else
	{
		printf("Error::Difficulty in checking source file extenstion in .bmp.\n");
		printf("Difficulty in checking file extenstion\n");
		return e_failure;
	}
}
Status open_img_file(DecodeInfo *decInfo)
{
	//Opening input file
	printf("Open files process started\n");
	decInfo -> encoded_image_fptr = fopen(decInfo -> encoded_image_fname, "r");
	//Do error handling
       	if (decInfo -> encoded_image_fptr == NULL)
    	{
		//It will print the type error automatically
        	perror("fopen");
        	fprintf(stderr, "ERROR: Unable to open file %s\n", decInfo -> encoded_image_fname);
		//If file is equal to returning e_failure

        	return e_failure;
    	}
	return e_success;	

}
Status skip_bmp_header(FILE *encoded_image_fptr)
{
	//By using fseek pointing file pointer to 54 byte
	fseek(encoded_image_fptr, 54, SEEK_SET);
	return e_success;

}
Status decode_magic_string(DecodeInfo *decInfo)
{
	const int len = strlen(MAGIC_STRING);
	char magic_string[len + 1];
	//Calling data from image function
	decode_data_from_image(magic_string, len, decInfo -> encoded_image_fptr);
	magic_string[2] = '\0';
	//Checking decoded magic string and macro magic string both are equal or not
	//printf("%s\n",magic_string);

	if(strcmp(magic_string, MAGIC_STRING) == 0)
	{
		//Both are equal return success
		return e_success;
	}
	else
	{
		//If Both are not equal return e_failure
		return e_failure;
	}

}
Status decode_data_from_image(char *decoded_data, int size, FILE *encoded_image_fptr)
{
	char buffer[8];
	for(int i = 0; i < size; i++)
	{
		//Reading 8 from input file
		fread(buffer, 8, 1, encoded_image_fptr);
		//Calling decode_byte_from_lsb and storing char pointer
		decoded_data[i] = decode_byte_from_lsb(buffer);
	}
	return e_success;
}
char decode_byte_from_lsb(char *image_buffer)
{
	int get, i;
	char ch = 0;
	for(int i = 0; i < 8; i++)
	{
		//Get the lsb bit and shift to msb
		get = (image_buffer[i] & 1) << (7 - i);
		//Replace using or operator
		ch = ch | get;
	       	
	}
	return ch;

}
Status decode_secret_file_extn_size( DecodeInfo *decInfo)
{
	char buffer[32];
	//Reading 32 from input file
	fread(buffer, 32, 1, decInfo -> encoded_image_fptr);
	//Storing extn size in structure member
	decInfo -> extn_size = decode_int_from_lsb(buffer);
	//printf("%d\n", decInfo -> extn_size);
	return e_success;

}
int decode_int_from_lsb( char *buffer)
{
	char result = 0, get;
	for (int i = 0; i < 32; i++)
	{
		//Get the lsb bit and shift to msb
		get = (buffer[i] & 1) << (31 - i);
		//Replace using (or) operator
		result = result | get;
	}
	return result;

}
Status decode_secret_file_extn(DecodeInfo *decInfo)
{
	char buffer[8];
	char data[decInfo -> extn_size + 1];
	int i;
	for (i = 0; i < decInfo -> extn_size; i++)
	{
		//Reading 8 from input file
		fread(buffer, 8, 1, decInfo -> encoded_image_fptr);
		//Calling function and storing in char array
        	data[i] = decode_byte_from_lsb(buffer);
	}
	data[i] = '\0';
	//Concatinating extn and file name
	strcat(decInfo -> output_fname, data);
	decInfo -> output_secret_fname = decInfo -> output_fname;
	printf("Secret message file::%s\n",decInfo -> output_secret_fname);
	//Opening output file in write mode
	decInfo -> output_secret_fptr = fopen(decInfo -> output_secret_fname, "w");
	//Do error handling
	if (decInfo -> output_secret_fptr == NULL)
	{
		//It will print the type error automatically
		perror("fopen");
		fprintf(stderr, "ERROR: Unable to open file %s\n", decInfo -> output_fname);
		return e_failure;
	}
	//If file opened return success
	printf("Secret file opened successfully\n");
	return e_success;
}
Status decode_secret_file_size(DecodeInfo *decInfo)
{
	char buffer[32];
	//Reading 32 bytes from input file
	fread(buffer, 32, 1, decInfo -> encoded_image_fptr);
	decInfo -> secret_file_size = decode_int_from_lsb(buffer);
	//printf("%d\n", decInfo -> secret_file_size);
	return e_success;

}	
Status decode_secret_file_data(DecodeInfo *decInfo)
{
    char buffer[8];
    for(int i = 0; i < decInfo->secret_file_size; i++)
    {
	//Reading 8 bytes from input file
        fread(buffer, 8, 1, decInfo-> encoded_image_fptr);
        decInfo->secret_file_data[i] = decode_byte_from_lsb(buffer);
	//printf("%c ",decInfo->secret_file_data[i]);
	//Storing secret data in output file
        putc(decInfo->secret_file_data[i],decInfo-> output_secret_fptr);
    }
    decInfo->secret_file_data[decInfo->secret_file_size] = '\0'; 
     
    return e_success;

}
Status do_decoding(DecodeInfo *decInfo)
{
	//open image file
        if (open_img_file(decInfo) == e_success)
        {
		printf("File opened Successfully.\n");
		//Skip bmp header
                if (skip_bmp_header(decInfo -> encoded_image_fptr) == e_success)
                {
			printf("Decoding magic string\n");
			//Magic string
                        if (decode_magic_string(decInfo) == e_success)
			{
				printf("Magic String Decoded Successfully.\n");
				printf("Decoding Secret file extenstion size.\n");
				//Secret file extenstion size
				if (decode_secret_file_extn_size(decInfo) == e_success)
				{
					printf("Secret file extenstion size Decoded Successfully.\n");
					printf("Decoding Secret file extenstion\n");
					//Secret file extenstion 
					if (decode_secret_file_extn(decInfo) == e_success)
					{
						printf("Secret file extenstion Decoded Successfully.\n");
						printf("Decoding Secret file size.\n");
						//secret file size
						if (decode_secret_file_size(decInfo) == e_success)
						{
							printf("Secret file size Decoded Successfully.\n");
							printf("Decoding secret data.\n"); 
							//secret file data
							if (decode_secret_file_data(decInfo) == e_success)
							{
								 printf("Secret data Decoded Successfully.\n");
								 fclose(decInfo->encoded_image_fptr);
								 fclose(decInfo->output_secret_fptr);
								 printf("all files closed successfully\n");
								 printf("decoding completed\n");

							}
							else
							{
								printf("Decoded Unsuccessfully\n");
								return e_failure;
							}

						}
						else
						{
							 printf("Decoded Unsuccessfully\n");
                                                         return e_failure;
						}



					}
					else
					{
						 printf("Decoded Unsuccessfully\n");
                                                 return e_failure;
					}

				}
				else
				{
					 printf("Decoded Unsuccessfully\n");
                                         return e_failure;
				}

			}
			else
			{
				 printf("Decoded Unsuccessfully\n");
                                 return e_failure;
			}

                }
		else
		{
			 printf("Decoded Unsuccessfully\n");
                         return e_failure;
		}

        }
	else
	{
		 printf("Decoded Unsuccessfully\n");
                 return e_failure;
	}



}




