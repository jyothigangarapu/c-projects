
#ifndef DECODE_H
#define DECODE_H

#include "types.h"

typedef struct _DecodeInfo
{
	char *encoded_image_fname;
	FILE *encoded_image_fptr;
	
	char *output_secret_fname;
	FILE *output_secret_fptr;
	int extn_size;
	int secret_file_size;
	char secret_file_data[1000];
	char output_fname[100];


} DecodeInfo;


/* Decoding function prototype */

/* Read and validate Encode args from argv */
Status read_and_validate_decode_args(char *argv[], DecodeInfo *decInfo);

/* Perform the encoding */
Status do_decoding(DecodeInfo *decInfo);

/* Get File pointers for i/p and o/p files */
Status open_img_file(DecodeInfo *decInfo);

Status skip_bmp_header(FILE *encoded_image_fptr);

/* Store Magic String */
Status decode_magic_string(DecodeInfo *decInfo);

Status decode_data_from_image(char *decoded_data, int size, FILE *encoded_image_fptr);

/*Decode the extn size */
Status decode_secret_file_extn_size( DecodeInfo *decInfo);

/* Decode secret file extenstion */
Status decode_secret_file_extn(DecodeInfo *decInfo);

/* Decode secret file size */
Status decode_secret_file_size( DecodeInfo *decInfo);

/* Decode secret file data*/
Status decode_secret_file_data(DecodeInfo *decInfo);

/* Decode a byte into LSB of image data array */
char decode_byte_from_lsb( char *image_buffer);

/*Decode the int to lsb */
int decode_int_from_lsb( char *buffer);


#endif
                                       
