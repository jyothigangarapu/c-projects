#ifndef FILE_H  // Preprocessor directive to prevent multiple inclusions of this header file
#define FILE_H

#include "contact.h"  // Including the contact.h header for the definition of AddressBook and Contact structures

// Function prototypes for saving and loading contacts to/from a file
void saveContactsToFile(AddressBook *addressBook);  // Function to save contacts to a file
void loadContactsFromFile(AddressBook *addressBook); // Function to load contacts from a file

#endif  // End of the header guard

