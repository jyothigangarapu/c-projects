#include <stdio.h>
#include "file.h"

// Function to save contacts from the address book to a file
void saveContactsToFile(AddressBook *addressBook)
{
    // Open the file contacts.csv for writing 
    FILE *fptr = fopen("contacts.csv", "w");
    
    // Check if the file was opened successfully
    if(fptr == NULL)
    {
        return;  // If file couldn't be opened, exit the function
    }
    else
    {
        // Write the total count of contacts as the first line in the file
        fprintf(fptr, "#%d\n", (addressBook->contactCount));
        
        // Loop through each contact and save their details to the file
        for(int i = 0; i < addressBook->contactCount; i++)
        {
            // Write the name, phone number, and email of each contact to the file
            fprintf(fptr,"%s,", addressBook->contacts[i].name);
            fprintf(fptr,"%s,", addressBook->contacts[i].phone);
            fprintf(fptr,"%s\n", addressBook->contacts[i].email);
        }
    }
}

// Function to load contacts from the file into the address book
void loadContactsFromFile(AddressBook *addressBook)
{
    // Open the file contacts.csv for reading
    FILE *fptr = fopen("contacts.csv", "r");
    
    // Check if the file was opened successfully
    if(fptr == NULL)
    {
        return;  // If file couldn't be opened, exit the function
    }
    else
    {
        // Read the number of contacts from the first line of the file
        fscanf(fptr, "#%d\n", &(addressBook->contactCount));
        
        // Loop through the file and load each contact's information
        for(int i = 0; i < addressBook->contactCount; i++)
        {
            // Read the contact details (name, phone, email) from the file
            fscanf(fptr, "%[^,],", addressBook->contacts[i].name);  // Read name
            fscanf(fptr, "%[^,],", addressBook->contacts[i].phone); // Read phone number
            fscanf(fptr, "%[^\n]\n", addressBook->contacts[i].email); // Read email
        }
    }
}
