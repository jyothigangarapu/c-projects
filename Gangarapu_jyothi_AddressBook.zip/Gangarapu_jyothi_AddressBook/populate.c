#include "contact.h"  // Include the contact.h header to access AddressBook and Contact structs

// Dummy contact data
static Contact dummyContacts[] = {
    {"Alice Smith", "0987654321", "alice@example.com"},
    {"Bob Johnson", "1112223333", "bob@company.com"},
    {"Carol White", "4445556666", "carol@company.com"},
    {"David Brown", "7778889999", "david@example.com"},
    {"Eve Davis", "6665554444", "eve@example.com"}
};

// Function to populate the AddressBook with dummy contacts
void populateAddressBook(AddressBook *addressBook)
{
    // Calculate the number of dummy contacts in the array
    int numDummyContacts = sizeof(dummyContacts) / sizeof(dummyContacts[0]);
    
    // Iterate through each dummy contact and add it to the AddressBook
    for (int i = 0; i < numDummyContacts; i++)
    {
        addressBook->contacts[addressBook->contactCount++] = dummyContacts[i]; // Add contact and increment contact count
    }
}
