/* Documentation
      Name : Gangarapu Jyothi
  Batch id : 24038_039
      Date : 16/03/2025
  Batch No : 24038
   Project : AddressBook
 */

   #include "contact.h"

int main()//main function
{
	AddressBook addressBook;   //memory allocation
	initialize(&addressBook);  //function call to store the contact count and contact details
int num1=1;  // initialize variable to run a loop
while(num1)   //if condition is true enter into a loop
{
	int opt;  // take variable to enter the option of choice
	printf("\n-------Address Book Menu:-----\n"); // print the functions list 
	printf("       1. Create contact        \n");
	printf("       2. Search contact        \n");  
	printf("       3. Edit contact          \n");     
	printf("       4. Delete contact        \n");  
	printf("       5. List all contacts     \n");  
	printf("       6. save and exit         \n");
	printf("Enter your choice: ");  //  prompt the user to enter the choice
	scanf("%d",&opt);    //read the input from the user
	switch(opt)  // initialize switch case
	{
		case 1:
		createContact(&addressBook);  //function call to create contact
		break;
		case 2:
		searchContact(&addressBook);  //function call to search contact
		break;
		case 3:
		 editContact(&addressBook);    //function call to edit the contact
		break;
		case 4:  
		deleteContact(&addressBook);  //function call to delete the contact
		break;
		case 5:
		listContacts(&addressBook);   //function call to display the contacts
		break;
		case 6:
		saveContactsToFile(&addressBook);  //function call to save the contacts into file
		return 0;
	}
	printf("1 for continue\n0 for exit \n");   // ask the user to continue or exit
	scanf("%d",&num1);
}

return 0;  // terminate the main program
}