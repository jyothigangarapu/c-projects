#include <stdlib.h>  // Include standard library for memory allocation and other utility functions
#include <string.h>  // Include string library for string manipulation functions
#include "contact.h" // Include the header for contact-related functions
#include "file.h"    // Include the header for file-related functions
#include "populate.h"// Include the header for population-related functions
#include  <ctype.h>   //Include the header for ctype-related functions

// Function to validate the entered name
void validate_name(char* name, int* res)
 {
    // Loop through each character in the entered name
    for (int j = 0; j < strlen(name); j++) {
        // Check if the character is a letter (uppercase or lowercase) or a space
        if ((name[j] >= 'A' && name[j] <= 'Z') || (name[j] >= 'a' && name[j] <= 'z') || (name[j] == ' ')) {
            *res = 0;  // Name is valid so set result to 0 (valid)
        }
        else {
            *res = 1;  // Name is invalid, so set result to 1 (invalid)
            printf("entered name is invalid\n");  // Print an error message
            return;  // Return from the function early if the name is invalid
        }
    }
    return;  // Return from the function if the name is valid
}
// Function to validate the entered number
void validation_number(char* number, int *num) 
{
    int mobile_length = strlen(number);  // Get the length of the number string

    if(mobile_length == 10)  // Check if the number length is 10
    {
        for(int i = 0; i < mobile_length; i++)  // Loop through each character in the number
        {
            if(number[i] >= '0' && number[i] <= '9')  // Check if the character is a digit (between '0' and '9')
            {
                *num = 0;  // Set num to 0 if the character is a valid digit
            }
            else
            {
                *num = 1;  // Set num to 1 if an invalid character (non-digit) is found
            }
        }
    }
}
void validation_mail(char* mail, int* res1) 
{
    int length = strlen(mail), flag = 0;  // Get the length of the mail and initialize the flag to 0
    const char mail_suffix[] = "@gmail.com";  // Define the suffix for a valid Gmail address
    int length1 = strlen(mail_suffix);  // Get the length of the Gmail suffix
    
    if(length < length1)  // Check if the length of the mail is less than the length of the suffix
    {
        flag = 1;  // If true, mark the mail as invalid
    }

    if(mail[length] != '\0')  // Check if the last character of the mail is the null terminator
    {
        flag = 1;  // If the mail is not properly terminated, mark it as invalid
    }

    if(strcmp(mail + length - length1, mail_suffix) != 0)  // Check if the mail ends with the valid suffix
    {
        flag = 1;  // If not, mark the mail as invalid
    }

    int username_length = length - length1 - 1;  // Calculate the length of the username (excluding the suffix)
    
    for(int i = 0; i < username_length; i++)  // Loop through each character in the username
    {
        if(mail[i] >= 'A' || mail[i] <= 'Z')  // Check if any character is an uppercase letter
        {
            flag = 1;  // If an uppercase letter is found, mark the mail as invalid
        }
    }

    if(flag == 1)  // If the mail is invalid (flag is set to 1)
    {
        *res1 = 1;  // Set res1 to 1 to indicate invalid mail
        printf("invalid mail\n");  // Print the invalid mail message
    }
    else
    {
        *res1 = 0;  // Set res1 to 0 to indicate valid mail
    }
}
// Function to validate the entered mobile number
void validate_number(char *ptr1, AddressBook *addressBook, int *res) 
{
    int num_exist = 0;  // Variable to track if the number already exists in the address book
    int mobile_len = strlen(ptr1);  // Get the length of the entered mobile number
    
    if (mobile_len == 10)  // Check if the mobile number length is exactly 10
    {
        int mobile_flag = 0;  // Flag to check if the number contains any invalid characters
        
        for (int i = 0; i < mobile_len; i++)  // Loop through each digit of the mobile number
        {   
            if (ptr1[i] >= '0' && ptr1[i] <= '9')  // Check if the character is a valid digit
                *res = 0;  // If valid, set res to 0 (valid number)
            else
            {   
                mobile_flag = 1;  // Set the flag to 1 if an invalid character is found
                *res = 1;  // Set res to 1 (invalid number)
                printf("You entered invalid mobile number\n");  // Print error message
                return;  // Exit the function as the number is invalid
            }       
        }

        if (mobile_flag == 0)  // If no invalid character is found in the number
        {
            // Check if the number already exists in the address book
            for (int j = 0; j < addressBook->contactCount; j++) 
            {
                if (strcmp(addressBook->contacts[j].phone, ptr1) == 0)  // Compare the number with existing numbers
                {
                    num_exist = 1;  // If number already exists, set num_exist to 1
                    *res = 1;  // Set res to 1 (number already exists)
                    printf("Entered number already exists\n");  // Print error message
                }
            }
        }
    }
    else  // If the mobile number length is not 10
    {
        *res = 1;  // Set res to 1 (invalid length)
        printf("You entered insufficient mobile number\n");  // Print error message
        return;  // Exit the function as the number length is invalid
    }
}

// Function to validate the entered email address
void validate_mail(char* mail, AddressBook *addressBook, int* res1) 
{
    int length = strlen(mail), flag = 0;  // Get the length of the email and initialize flag
    const char mail_suffix[] = "@gmail.com";  // Define the valid email suffix
    int length1 = strlen(mail_suffix);  // Get the length of the suffix
    
    if (length < length1)  // Check if the email length is smaller than the suffix length
    {
        flag = 1;  // If true, set flag to 1 (invalid email)
    }

    if (mail[length] !='\0')  // Check if the last character of the email is null terminator
    {
        flag = 1;  // If not, set flag to 1 (invalid email)
    }

    if (strcmp(mail + length - length1, mail_suffix) != 0)  // Check if the email ends with the valid suffix
    {
        flag = 1;  // If not, set flag to 1 (invalid email)
    }

    int username_length = length - length1 - 1;  // Calculate the length of the username part of the email
    
    for (int i = 0; i < username_length; i++)  // Loop through each character in the username part
    {
        if (mail[i] >= 'A' && mail[i] <= 'Z')  // Check if any character is an uppercase letter (invalid)
        {
            flag = 1;  // Set flag to 1 (invalid email)
        }
    }

    // Check if the entered email already exists in the address book
    for (int i = 0; i < length; i++) 
    {
        if (strcmp(addressBook->contacts[i].email, mail) == 0)  // Compare with existing emails
        {
            *res1 = 1;  // Set res1 to 1 (email already exists)
            printf("Entered email already exists\n");  // Print error message
            return;  // Exit the function as the email already exists
        }
    }

    if (flag == 1)  // If any invalid conditions were detected
    {
        *res1 = 1;  // Set res1 to 1 (invalid email)
        printf("Invalid email\n");  // Print error message
    }
    else
    {
        *res1 = 0;  // Set res1 to 0 (valid email)
    }
}

// Function to list all contacts in the AddressBook
void listContacts(AddressBook *addressBook) 
{   
printf("+----------------------+----------------+------------------------------+\n");
     printf("| %-20s | %-14s | %-28s |\n", "Name", "phone", "Email");
     printf("+----------------------+----------------+------------------------------+\n");


     // Loop through all contacts in the addressBook
     for (int i = 0; i < addressBook->contactCount; i++)
    {
        printf("| %-20s | %-14s | %-28s |\n",addressBook -> contacts[i].name, addressBook -> contacts[i].phone, addressBook -> contacts[i].email);        
    }
    printf("+----------------------+----------------+------------------------------+\n");
}
// Function to initialize the AddressBook
void initialize(AddressBook *addressBook)
{
    addressBook->contactCount = 0;  // Set the initial contact count to 0
    loadContactsFromFile(addressBook);  // Load contacts from file into the AddressBook
}

// Function to save contacts to file and exit the program
void saveAndExit(AddressBook *addressBook) {
    saveContactsToFile(addressBook);  // Save the current contacts to the file
    exit(EXIT_SUCCESS);  // Exit the program successfully
}
// Function to create a new contact in the AddressBook
void createContact(AddressBook *addressBook) 
{
    char name[20];  // Declare an array to store the name of the contact
    printf("enter the name:");  // Prompt the user to enter a name
    // Read the name from the user
    scanf(" %[^\n]",name);

    int res;  // Variable to store the result of name validation
    validate_name(name, &res);  // Validate the entered name

    // If the name is invalid, prompt again and check the result
    if (res == 1) 
    {
        printf("enter the name:");  // Prompt again to enter the name
        // Read the name from the user
        scanf(" %[^\n]", name);
        validate_name(name,&res);  // Validate the entered name again
        // If name validation fails twice, print a limit message and exit
        if (res == 1)
        {
            printf("limit exceeded\n");
            return;  // Exit the function if validation fails twice
        }
        else 
        {
            // If valid, copy the name to the contact's name field and notify success
            strcpy(addressBook->contacts[addressBook->contactCount].name, name);
            printf("name added successfully\n");
        }
    }
    else 
    {
        // If valid, copy the name to the contact's name field and notify success
        strcpy(addressBook->contacts[addressBook->contactCount].name, name);
        printf("name added successfully\n");
    }

    char number[15];  // Declare an array to store the phone number
    int num;  // Variable to store the result of phone number validation
    printf("enter the number:");  // Prompt the user to enter a phone number
    // Read the phone number from the user
    scanf(" %[^\n]",number);
    validate_number(number,addressBook,&num);  // Validate the entered phone number

    // If the phone number is invalid, prompt again and check the result
    if (num == 1) 
    {
        printf("enter the number:");  // Prompt again to enter the number
        scanf(" %[^\n]",number);  // Read the number from the user
        validate_number(number,addressBook,&num);  // Validate the entered number again
        // If validation fails twice, print a limit message and exit
        if (num == 1) 
        {
            printf("limit exceeded\n");
            return;  // Exit the function if validation fails twice
        }
        else 
        {
            // If valid, copy the phone number to the contact's phone field and notify success
            strcpy(addressBook->contacts[addressBook->contactCount].phone,number);
            printf("number added successfully\n");
        }
    }
    else 
    {
        // If valid, copy the phone number to the contact's phone field and notify success
        strcpy(addressBook->contacts[addressBook->contactCount].phone, number);
        printf("number added successfully\n");
    }

    char mail[30];  // Declare an array to store the email address
    int res1;  // Variable to store the result of email validation
    printf("enter the email:");  // Prompt the user to enter an email
    scanf(" %[^\n]",mail);  // Read the email from the user
    validate_mail(mail,addressBook,&res1);  // Validate the entered email

    // If the email is invalid, prompt again and check the result
    if (res1 == 1) 
    {
        printf("enter the email:");  // Prompt again to enter the email
        scanf(" %[^\n]",mail);  // Read the email from the user
        validate_mail(mail,addressBook,&res1);  // Validate the entered email again
        // If validation fails twice, print a limit message and exit
        if (res1 == 1) 
        {
            printf("limit exceeded\n");
            return;  // Exit the function if validation fails twice
        }
        else 
        {
            // If valid, copy the email to the contact's email field and notify success
            strcpy(addressBook->contacts[addressBook->contactCount].email, mail);
            printf("mail added successfully\n");
        }
    }
    else 
    {
        // If valid, copy the email to the contact's email field and notify success
        strcpy(addressBook->contacts[addressBook->contactCount].email, mail);
        printf("mail added successfully\n");
    }

    // Increment the contact count after adding a new contact
    addressBook->contactCount++;
    return;  // Return from the function after completing the contact creation
}
// Function to search for contacts in the AddressBook
void searchContact(AddressBook *addressBook) 
{
    /* Define the logic for search */
    int select, search_count = 0;  // Variables for menu selection and count of found contacts
    printf("1.search by name\n2.search by phone no\n3.search by email\n4.exit\n");  // Menu options for search
    scanf("%d",&select);  // Read the user's selection
     int  i, res;  // Flag to track if a contact is found, index, and result of validation
    switch(select) 
    {  // Switch based on user's selection
        case 1:  // Case for searching by name
             int flag=0;
            char str[20];  // Declare an array to store the search name
            printf("enter the name:");  // Prompt for name input
            scanf(" %[^\n]",str);  // Read the name from the user
            validate_name(str,&res);  // Validate the entered name
            if (res == 1) 
            {  // If name is invalid, call search again
                searchContact(addressBook);
            }
            else 
            {
                // Loop through contacts to search for the name
                for (i = 0; i < addressBook->contactCount; i++) 
                {
                    if (strcmp(addressBook->contacts[i].name,str) == 0) 
                    {  // If name matches
                        flag = 1;  // Set flag to indicate contact found
                        search_count++;  // Increment the search count
                        // Print the contact details
                        printf(" name:%s\n", addressBook->contacts[i].name);
                        printf(" phone:%s\n", addressBook->contacts[i].phone);
                        printf(" email:%s\n", addressBook->contacts[i].email);
                        printf("\n");
                    }
                }
                if(search_count>1)
                {
                    printf(" %d contacts found with same name\n",search_count);
                    printf("try with phone no or mail\n");
                }
                if(flag==1)
                {
                    searchContact(addressBook);
                }
                // If no match found, print a message and call search again
                if (flag == 0) 
                {
                    printf("contact not found\n");
                    searchContact(addressBook);
                }
            }
            break;
            case 2:  // Case for searching by phone number
            char num[12];  // Declare an array to store the phone number
            printf("enter the mobile number:\n");  // Prompt for phone number input
            scanf(" %[^\n]",num);  // Read the phone number from the user
            validation_number(num,&res);  // Validate the phone number
            if (res == 1) 
            {  // If number is invalid, call search again
                searchContact(addressBook);
            }
            else 
            {
                // Loop through contacts to search for the phone number
                for (i = 0; i < addressBook->contactCount; i++) 
                {
                    if (strcmp(addressBook->contacts[i].phone,num) == 0) // If phone number matches
                    {  
                        flag = 1;  // Set flag to indicate contact found
                        printf(" name:%s\n", addressBook->contacts[i].name);
                        printf(" phone:%s\n", addressBook->contacts[i].phone);
                        printf(" email:%s\n", addressBook->contacts[i].email);
                    }
                }
                // If a match is found, print the search menu details
                if (flag == 1) 
                {
                    searchContact(addressBook);
                }
                else 
                {  // If no match found, print a message and call search again
                    printf("contact not found\n");
                    searchContact(addressBook);
                }
            }
            break;
           case 3:  // Case for searching by email
            char mail[30];  // Declare an array to store the email address
            printf("enter the mail id\n");  // Prompt for email input
            getchar();
            scanf(" %[^\n]",mail);  // Read the email from the user
            validation_mail(mail, &res);  // Validate the email
            if (res == 1) 
            {  // If email is invalid, call search again
                searchContact(addressBook);
            }
            else 
            {
                // Loop through contacts to search for the email
                for (i = 0; i < addressBook->contactCount; i++) {
                    if (strcmp(addressBook->contacts[i].email,mail) == 0) 
                    {  // If email matches
                        flag = 1;  // Set flag to indicate contact found
                        printf(" name:%s\n", addressBook->contacts[i].name);
                        printf(" phone:%s\n", addressBook->contacts[i].phone);
                        printf(" email:%s\n", addressBook->contacts[i].email);
                        printf("\n");
                    }
                }
                // If a match is found, print the contact details
                if (flag == 1) 
                {
                    searchContact(addressBook);
                }
                else {  // If no match found, print a message and call search again
                    printf("contact not found\n");
                    searchContact(addressBook);
                }
            }
            break;
        case 4:  // Case to exit the search function
        return;  // Exit the function

    } 
}

void editContact(AddressBook *addressBook)
{
    // Define the logic for editing a contact
    char name[30];           // To store the name of the contact to be edited
    char mail[20];           // To store the email of the contact to be edited
    char new_name[30];       // To store the new name of the contact
    char new_num[30];        // To store the new phone number of the contact
    char new_mail[30];       // To store the new email of the contact
    // Display the options for editing
    printf("1.edit by name\n2.edit by phone\n3.edit my mail\n4.exit\n");
    int option;
     printf("enter your option\n");
    scanf("%d",&option);    // Get the option selected by the user
    int i, index, found_count = 0,flag=0, res;
    int edit_opt;
   switch(option)
    {
        case 1:
            // Edit by name option
            printf("Enter the name: ");
            scanf(" %[^\n]",name);  // Get the name to search for
            validate_name(name,&res);
            int edit_arr[100];  // Array to hold indices of matching contacts
            int n = 0;
            if(res==1)
            {
                editContact(addressBook);
            }
            else
            {
            // Search for the contact by name
            for (i = 0; i < addressBook->contactCount; i++)
            {
                if (strcmp(addressBook->contacts[i].name, name) == 0)
                {
                    edit_arr[n++] = i;  // Store the matching index
                    // Display the contact details
                    printf("%d.Name:%s\n", i, addressBook->contacts[i].name);
                    printf("%d.phone:%s\n", i, addressBook->contacts[i].phone);
                    printf("%d.email:%s\n", i, addressBook->contacts[i].email);
                    printf("\n");
                    found_count++;
                }
            }
            
            // If no contact is found, prompt the user again
            if (found_count == 0)
            {
                printf("Name not found! Please try again.\n");
                editContact(addressBook);  // Recurse to try again
            }

            // If more than one contact is found, ask the user to specify which one to edit
            if (found_count >=1)
            {
                printf("%d contacts found with same name\n",found_count);
                printf("Enter the index of the contact you want to edit: ");
                scanf("%d",&index);
                getchar();
                if (index >= 0 && index <= addressBook->contactCount)
                {
                    for (int h = 0; h < addressBook->contactCount; h++)
                    {
                        if (index == edit_arr[h])  // Check if the index is valid
                        {
                            flag = 1;
                            break;
                        }
                    }
                    if (flag == 0)
                    {
                        printf("You entered an invalid choice! Please try again.\n");
                        editContact(addressBook);
                    }
                }
            }
           // If one contact or a valid contact is selected, allow editing
            if (found_count == 1 || flag == 1)
            {
                printf("Enter the field for which detail you want to edit:\n1.name\n2.number\n3.email\n4.exit\n");
                scanf("%d",&edit_opt);  // Get the field to edit
             switch(edit_opt)
                {
                    case 1:  // Edit name
                        printf("Enter the new name: ");
                        scanf(" %[^\n]",new_name);
                        validate_name(new_name,&res);
                        if (res == 1)  // Check if name validation failed
                        {
                            printf("Invalid name entered. Please try again.\n");
                            editContact(addressBook);  // Recursion to edit again
                        }
                        else
                        {
                            strcpy(addressBook->contacts[index].name,new_name);  // Update the name
                            printf("New name updated successfully.\n");
                            editContact(addressBook);  // Recursion to edit again
                        }
                        break;
                    case 2:  // Edit phone number
                        printf("Enter the new number: ");
                        scanf(" %[^\n]",new_num);
                        validate_number(new_num,addressBook,&res);  // Validate phone number
                        if (res == 1)  // If invalid number, prompt again
                        {
                            printf("Enter the new number: ");
                            scanf(" %[^\n]",new_num);
                         validate_number(new_num,addressBook,&res);  // Validate phone number
                        if (res == 1)  // If invalid number, prompt again
                        {
                            printf("limit exceeded\n");
                            editContact(addressBook);
                        }
                        else
                        {
                            strcpy(addressBook->contacts[index].phone, new_num);  // Update the phone number
                            printf("New number updated successfully.\n");
                            editContact(addressBook);  // Recursion to edit again
                        }
                        }
                        else
                        {
                            strcpy(addressBook->contacts[index].phone, new_num);  // Update the phone number
                            printf("New number updated successfully.\n");
                            editContact(addressBook);  // Recursion to edit again
                        }
                        break;
                    case 3:  // Edit email
                        printf("Enter the new email: ");
                        scanf(" %[^\n]",new_mail);
                        validate_mail(new_mail,addressBook, &res);  // Validate email
                        if (res == 1)  // If invalid email, prompt again
                        {
                            
                            printf("Enter the new email: ");
                            scanf(" %[^\n]",new_mail);
                            validate_mail(new_mail,addressBook, &res);  // Validate email
                            if (res == 1)  // If invalid email, prompt again
                            {
                                printf("limit exceeded\n");
                                editContact(addressBook);
                            }
                            else
                            {
                                strcpy(addressBook->contacts[index].email, new_mail);  // Update email
                                printf("New email updated successfully.\n");
                                editContact(addressBook);  // Recursion to edit again
                            }
                        }
                        else
                        {
                            strcpy(addressBook->contacts[index].email, new_mail);  // Update email
                            printf("New email updated successfully.\n");
                            editContact(addressBook);  // Recursion to edit again
                        }
                        break;
                        case 4:  // Exit the edit process
                        editContact(addressBook);
                }
            }
    }
            break;
            case 2:
            char num[20];  // Declare variable to store phone number input
            printf("Enter the number: ");
            scanf(" %[^\n]",num);  // Get the phone number to search for
            validation_number(num,&res);
            if(res==1)
            {
                editContact(addressBook);
            }
            else
            {
            // Loop through all contacts to find a matching phone number
            for (i = 0; i < addressBook->contactCount; i++)
            {
                if (strcmp(addressBook->contacts[i].phone, num) == 0)
                {
                    found_count++;  // Increment found_count when a match is found
                    index = i;  // Store the index of the found contact
                    printf("%d.Name:%s\n", i, addressBook->contacts[i].name);
                    printf("%d.phone:%s\n", i, addressBook->contacts[i].phone);
                    printf("%d.email:%s\n", i, addressBook->contacts[i].email);

                }
            }
        
            // If no contact with the entered number is found, ask the user to try again
            if (found_count == 0)
            {
                printf("Number not found! Please try again.\n");
                editContact(addressBook);
            }
        
            // If multiple contacts are found, ask the user to select which one to edit
            if (found_count > 1)
            {
                printf("Enter the index of the contact you want to edit: ");
                scanf("%d",&index);  // Get the index to edit
            }
        
            // If the index is valid, allow the user to choose what detail to edit
            if (index >= 0 && index <= addressBook->contactCount)
            {
                printf("Enter your choice for which detail you want to edit:\n1.name\n2.number\n3.email\n4.exit");
                scanf("%d",&edit_opt);  // Get the choice to edit name, phone, email, or exit
                // Switch case for editing different details
                switch (edit_opt)
                {
                    case 1:  // Edit the name
                        printf("Enter the new name: ");
                        scanf(" %[^\n]", new_name);  // Get the new name
                        getchar();
                        validate_name(new_name, &res);  // Validate the name
        
                        if (res == 1)  // If name is invalid
                        {
                            printf("Enter the new name: ");
                            scanf(" %[^\n]", new_name);  // Get the new name again
                            getchar();
                            validate_name(new_name,&res);  // Validate the name again
                            
                            if (res == 1)  // If still invalid
                            {
                                printf("limit exceeded\n");  // Error message when validation fails
                                editContact(addressBook);  // Recursively call the function to retry
                            }
                            else
                            {
                                strcpy(addressBook->contacts[index].name, new_name);  // Update the name
                                printf("New name updated successfully.\n");
                                editContact(addressBook);  // Recursively call to allow further edits
                            }
                        }
                        else
                        {
                            strcpy(addressBook->contacts[index].name, new_name);  // Update the name
                            printf("New name updated successfully.\n");
                            editContact(addressBook);  // Recursively call to allow further edits
                        }
                        break;
                        case 2:  // Edit the phone number
                        printf("Enter the new number: ");
                        scanf(" %[^\n]", new_num);  // Get the new phone number
                        getchar();
                        validate_number(new_num,addressBook, &res);  // Validate the new phone number
        
                        if (res == 1)  // If number is invalid
                        {
                            printf("Enter the new number: ");
                            scanf(" %[^\n]", new_num);  // Get the new number again
                            getchar();
                            validate_number(new_num,addressBook, &res);  // Validate the number again
        
                            if (res == 1)  // If still invalid
                            {
                                printf("limit exceeded\n");  // Error message when validation fails
                                editContact(addressBook);  // Recursively call the function to retry
                            }
                            else
                            {
                                strcpy(addressBook->contacts[index].phone, new_num);  // Update the phone number
                                printf("New number updated successfully.\n");
                                editContact(addressBook);  // Recursively call to allow further edits
                            }
                        }
                        else
                        {
                            strcpy(addressBook->contacts[index].phone, new_num);  // Update the phone number
                            printf("New number updated successfully.\n");
                            editContact(addressBook);  // Recursively call to allow further edits
                        }
                        break;
                     case 3:  // Edit the email address
                        printf("Enter the new email: ");
                        scanf(" %[^\n]", new_mail);  // Get the new email address
                        getchar();
                        validate_mail(new_mail,addressBook, &res);  // Validate the new email
        
                        if (res == 1)  // If email is invalid
                        { 
                                  printf("Enter the new email: ");
                                 scanf(" %[^\n]", new_mail);  // Get the new email address
                                  getchar();
                                  validate_mail(new_mail,addressBook, &res);  // Validate the new email
        
                            if (res == 1)  // If email is invalid
                            { 
                                printf("limit exceeded\n");
                                editContact(addressBook);  // Recursively call the function to retry
                            }
                            else
                            {
                                strcpy(addressBook->contacts[index].email, new_mail);  // Update the email
                                printf("New email updated successfully.\n");
                                editContact(addressBook);  // Recursively call to allow further edits
                            }
                        }
                        else
                        {
                            strcpy(addressBook->contacts[index].email, new_mail);  // Update the email
                            printf("New email updated successfully.\n");
                            editContact(addressBook);  // Recursively call to allow further edits
                        }
                        break;
        
                    case 4:  // Exit the edit process
                    {
                        editContact(addressBook);  // Recursively call to exit and return
                    }
                }
            }
        }
            break;
            case 3:
            printf("Enter the email:\n");
            scanf(" %[^\n]",mail);  // Get the email to search for
            validation_mail(mail,&res);
            if(res==1)
            {
             editContact(addressBook);
            }
            else
            {
            // Loop through all contacts to find a matching email
            for (i = 0; i < addressBook->contactCount; i++)
            {
                if (strcmp(addressBook->contacts[i].email, mail) == 0)
                {
                    found_count++;  // Increment found_count when a match is found
                    index = i;  // Store the index of the found contact
                    printf("%d.Name:%s\n", i, addressBook->contacts[i].name);
                    printf("%d.phone:%s\n", i, addressBook->contacts[i].phone);
                    printf("%d.email:%s\n", i, addressBook->contacts[i].email);
                }
            }
        
            // If no contact with the entered email is found, ask the user to try again
            if (found_count == 0)
            {
                printf("Number not found! Please try again.\n");
                  editContact(addressBook);
            }
        
            // If multiple contacts are found, ask the user to select which one to edit
            if (found_count > 1)
            {
                printf("Enter the index of the contact you want to edit: ");
                scanf("%d", &index);  // Get the index to edit
                getchar();
            }
        
            // If the index is valid, allow the user to choose what detail to edit
            if (index >= 0 && index <= addressBook->contactCount)
            {
                printf("Enter your choice for which detail you want to edit:\n 1.name\n 2.number\n 3.email\n4.exit\n");
                scanf("%d",&edit_opt);  // Get the choice to edit name, phone, email, or exit
                
                // Switch case for editing different details
                switch (edit_opt)
                {
                    case 1:  // Edit the name
                        printf("Enter the new name: ");
                        scanf(" %[^\n]", new_name);  // Get the new name
                        getchar();
                        validate_name(new_name, &res);  // Validate the name
        
                        if (res == 1)  // If name is invalid
                        {
                            printf("Enter the new name: ");
                            scanf(" %[^\n]", new_name);  // Get the new name again
                            getchar();
                            validate_name(new_name, &res);  // Validate the name again
                            
                            if (res == 1)  // If still invalid
                            {
                                printf("limit exceeded\n");  // Error message when validation fails
                                editContact(addressBook);  // Recursively call the function to retry
                            }
                            else
                            {
                                strcpy(addressBook->contacts[index].name, new_name);  // Update the name
                                printf("New name updated successfully.\n");
                                editContact(addressBook);  // Recursively call to allow further edits
                            }
                        }
                        else
                        {
                            strcpy(addressBook->contacts[index].name, new_name);  // Update the name
                            printf("New name updated successfully.\n");
                            editContact(addressBook);  // Recursively call to allow further edits
                        }
                        break;
        
                    case 2:  // Edit the phone number
                        printf("Enter the new number: ");
                        scanf(" %[^\n]", new_num);  // Get the new phone number
                        getchar();
                        validate_number(new_num,addressBook, &res);  // Validate the new phone number
        
                        if (res == 1)  // If number is invalid
                        {
                            printf("Enter the new number: ");
                            scanf(" %[^\n]", new_num);  // Get the new number again
                            getchar();
                            validate_number(new_num,addressBook, &res);  // Validate the number again
        
                            if (res == 1)  // If still invalid
                            {
                                printf("limit exceeded\n");  // Error message when validation fails
                                editContact(addressBook);  // Recursively call the function to retry
                            }
                            else
                            {
                                strcpy(addressBook->contacts[index].phone, new_num);  // Update the phone number
                                printf("New number updated successfully.\n");
                                editContact(addressBook);  // Recursively call to allow further edits
                            }
                        }
                        else
                        {
                            strcpy(addressBook->contacts[index].phone, new_num);  // Update the phone number
                            printf("New number updated successfully.\n");
                            editContact(addressBook);  // Recursively call to allow further edits
                        }
                        break;
        
                    case 3:  // Edit the email address
                        printf("Enter the new email: ");
                        scanf(" %[^\n]", new_mail);  // Get the new email address
                        getchar();
                        validate_mail(new_mail,addressBook, &res);  // Validate the new email
        
                        if (res == 1)  // If email is invalid
                        { 
                            printf("Enter the new email: ");
                            scanf(" %[^\n]", new_mail);  // Get the new email again
                            getchar();
                            validate_mail(new_mail,addressBook, &res);  // Validate the email again
                            
                            if (res == 1)  // If still invalid
                            { 
                                printf("limit exceeded\n");  // Error message when validation fails
                                editContact(addressBook);  // Recursively call the function to retry
                            }
                            else
                            {
                                strcpy(addressBook->contacts[index].email, new_mail);  // Update the email
                                printf("New email updated successfully.\n");
                                editContact(addressBook);  // Recursively call to allow further edits
                            }
                        }
                        else
                        {
                            strcpy(addressBook->contacts[index].email, new_mail);  // Update the email
                            printf("New email updated successfully.\n");
                            editContact(addressBook);  // Recursively call to allow further edits
                        }
                        break;
        
                    case 4:  // Exit the edit process
                    {
                        editContact(addressBook);  // Exit the function without making any changes
                    }
                }
            }
        }
            break;
        case 4:
            return;
    }
}
  void deleteContact(AddressBook *addressBook)
        {
            char delete[30];  // To store the user input (name, phone number, or email)
            printf("Select Your choice :\n 1.delete by name\n 2.delete by phone\n 3.delete by Email id\n 4.exit\n");
            int option,res;
            scanf("%d", &option);  // Get the user's choice for deletion method
            getchar();  // To consume any leftover newline character from the input buffer
        
            switch(option)
            {
                case 1:  // Case to delete by name
                    printf("Enter the name : \n");
                    scanf(" %[^\n]",delete);  // Get the name to delete
                    validate_name(delete,&res);
                    if(res==1)
                    {
                        deleteContact(addressBook);
                    }
                    else
                    {
                    int name_found = 0;  // Flag to track if the name was found
                    int s;  // Variable to store the index of the contact to be deleted
                    int delete_arr[200];  // Array to store indices of contacts with the same name
                    int n = 0;  // Counter for storing indices in delete_arr
        
                    // Loop through all contacts and find matches by name
                    for(int i = 0; i < addressBook->contactCount; i++)
                    {
                        if(strcmp(addressBook->contacts[i].name, delete) == 0)
                        {
                            name_found++;  // Increment the counter if name matches
                            delete_arr[n++] = i;  // Store the index of the matching contact
                            // Display the contact details
                            printf(" %d. name:%s\n", i, addressBook->contacts[i].name);
                            printf(" %d. phone:%s\n", i, addressBook->contacts[i].phone);
                            printf(" %d. email:%s\n", i, addressBook->contacts[i].email); 

                        } 
                    }
        
                    int flag = 0;  // Flag to track if a valid index is selected
                    if(name_found >= 1)  // If multiple contacts with the same name are found
                    {
                        int name_index;
                        printf("%d contacts found with the same name\n",name_found); 
                        printf("Enter the index position from the above contacts you want to delete : \n");
                        scanf("%d", &name_index);  // Get the index of the contact to delete
                        // Check if the entered index is valid
                        for(int h = 0; h < addressBook->contactCount; h++)
                        {
                            if(name_index == delete_arr[h])
                            {
                                flag = 1;  // Set flag to 1 if the index is valid
                                s = name_index;  // Store the index of the contact to delete
                                break;
                            }
                        }
                        if(flag == 0)  // If invalid index is entered
                        {
                            printf("You entered an invalid choice! Please try again\n");
                            deleteContact(addressBook);  // Call the function again to retry
                        }
                    }
        
                    if(flag == 1 || name_found == 1)  // If a valid contact is found
                    {
                        // Shift contacts after the deleted one to fill the gap
                        for(int j = s; j < addressBook->contactCount-1; j++)
                        {
                            addressBook->contacts[j] = addressBook->contacts[j+1];
                        }
                        printf("Contact deleted successfully\n");
                        addressBook->contactCount--;  // Decrease the contact count
                        deleteContact(addressBook);  // Exit the function
                    }
        
                    if(name_found == 0)  // If no contact is found with the entered name
                    {
                        printf("Contact name is not found! Please try again\n");
                        deleteContact(addressBook);  // Call the function again to retry
                    }
                }
                    break;
                case 2:  // Case to delete by phone number
                    printf("Enter the number : ");
                    scanf("%s", delete);  // Get the phone number to delete
                    validation_number(delete,&res);
                    if(res==1)
                    {
                        deleteContact(addressBook);
                    }
                    else
                    {
                    int number_found = 0;  // Flag to track if the phone number was found
        
                    // Loop through all contacts and find matches by phone number
                    for(int i = 0; i < addressBook->contactCount-1; i++)
                    {
                        if(strcmp(addressBook->contacts[i].phone, delete) == 0)
                        {
                            number_found = 1;  // Set the flag if the phone number matches
                            // Shift contacts after the deleted one to fill the gap
                            printf("%d.Name:%s\n", i, addressBook->contacts[i].name);
                            printf("%d.phone:%s\n", i, addressBook->contacts[i].phone);
                            printf("%d.email:%s\n", i, addressBook->contacts[i].email);
                            for(int j = i; j < addressBook->contactCount; j++)
                            {
                                addressBook->contacts[j] = addressBook->contacts[j + 1];
                            }
                            printf("Contact deleted successfully\n");
                            addressBook->contactCount--;  // Decrease the contact count
                            deleteContact(addressBook);  // Exit the function
                        }
                    }
        
                    if(number_found == 0)  // If no contact is found with the entered phone number
                    {
                        printf("Contact number is not found! Please try again\n");
                        deleteContact(addressBook);  // Call the function again to retry
                    }
                }
                    break;
        
                case 3:  // Case to delete by email
                    printf("Enter the mail ID : ");
                    scanf("%s", delete);  // Get the email ID to delete
                    validation_mail(delete,&res);
                    if(res==1)
                    {
                        deleteContact(addressBook);
                    }
                    else
                    {
                    int mail_found = 0;  // Flag to track if the email was found
                    int s1;  // Variable to store the index of the contact to be deleted
        
                    // Loop through all contacts and find matches by email
                    for(int k = 0; k < addressBook->contactCount-1; k++)
                    {
                        if(strcmp(addressBook->contacts[k].email, delete) == 0)
                        {
                            mail_found++;  // Increment the counter if email matches
                            // Display the contact details
                            printf(" name:%s\n", addressBook->contacts[k].name);
                            printf(" phone:%s\n", addressBook->contacts[k].phone);
                            printf(" email:%s\n", addressBook->contacts[k].email);   
                        }
                    }
        
                    if(mail_found == 1)  // If a matching contact is found
                    {
                        // Shift contacts after the deleted one to fill the gap
                        for(int j = s1; j < addressBook->contactCount-1; j++)
                        {
                            addressBook->contacts[j] = addressBook->contacts[j+ 1];
                        }
                        printf("Contact deleted successfully\n");
                        addressBook->contactCount--;  // Decrease the contact count
                        deleteContact(addressBook);  // Exit the function
                    }
                    else  // If no contact is found with the entered email
                    {
                        printf("Contact mail is not found! Please try again\n");
                        deleteContact(addressBook);  // Call the function again to retry
                    }
                }
                    break;
        
                case 4:  // Exit case
                    return;  // Exit the function without making any changes
            }
        }
        
