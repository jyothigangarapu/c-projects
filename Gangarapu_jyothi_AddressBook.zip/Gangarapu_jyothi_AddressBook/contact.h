#ifndef CONTACT_H  // Preprocessor directive to avoid multiple inclusions of this header file
#define CONTACT_H

#include <stdio.h>  // Standard input-output library

// Define the maximum number of contacts that can be stored
#define MAX_CONTACTS 100

// Define the Contact structure with name, phone, and email fields
typedef struct Contact {
    char name[50];   // Name of the contact
    char phone[20];  // Phone number of the contact
    char email[50];  // Email address of the contact
} Contact;

// Define the AddressBook structure which holds an array of contacts and a count of contacts
typedef struct {
    Contact contacts[MAX_CONTACTS];  // Array to store multiple contacts
    int contactCount;  // To keep track of the number of contacts
} AddressBook;

// Function prototypes for operations on the AddressBook
void createContact(AddressBook *addressBook);  // Function to create a new contact
void searchContact(AddressBook *addressBook);  // Function to search for a contact
void editContact(AddressBook *addressBook);    // Function to edit an existing contact
void deleteContact(AddressBook *addressBook);  // Function to delete a contact
void listContacts(AddressBook *addressBook);   // Function to list all contacts
void initialize(AddressBook *addressBook);     // Function to initialize an empty address book
void saveContactsToFile(AddressBook *addressBook);  // Function to save contacts to a file

#endif  // End of the header guard

